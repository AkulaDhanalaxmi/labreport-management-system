(function(){
  const btnId = 'themeToggleBtn';
  function setTheme(dark){
    if(dark) document.body.classList.add('dark');
    else document.body.classList.remove('dark');
    localStorage.setItem('lab_theme_dark', dark? '1' : '0');
  }
  document.addEventListener('DOMContentLoaded', function(){
    const saved = localStorage.getItem('lab_theme_dark') === '1';
    setTheme(saved);
    const btn = document.getElementById(btnId);
    if(btn) btn.addEventListener('click', ()=> setTheme(!document.body.classList.contains('dark')) );
  });
})();
